import os
import joblib
import numpy as np
import pandas as pd
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go


# ============================================================
# PAGE CONFIGURATION
# ============================================================

st.set_page_config(
    page_title="Personal Budget DSS | Kiran Dasangri Chalapathi",
    page_icon="💷",
    layout="wide",
    initial_sidebar_state="expanded"
)


# ============================================================
# CUSTOM PROFESSIONAL CSS THEME
# ============================================================

st.markdown(
    """
    <style>

    /* ============================================================
       GLOBAL APP BACKGROUND
    ============================================================ */

    .stApp {
        background:
            radial-gradient(circle at top left, rgba(244, 114, 182, 0.18), transparent 32%),
            radial-gradient(circle at top right, rgba(20, 184, 166, 0.16), transparent 30%),
            linear-gradient(135deg, #fff7ed 0%, #fdf2f8 42%, #f8fafc 100%);
        color: #22151c;
    }

    .block-container {
        padding-top: 1.6rem;
        padding-left: 2.5rem;
        padding-right: 2.5rem;
        padding-bottom: 2rem;
    }

    header[data-testid="stHeader"] {
        background: transparent;
    }

    #MainMenu {
        visibility: hidden;
    }

    footer {
        visibility: hidden;
    }

    /* ============================================================
       SIDEBAR
    ============================================================ */

section[data-testid="stSidebar"] {
    background:
        linear-gradient(180deg, #4b0f2e 0%, #6e1a4b 42%, #147d73 100%);
    border-right: 1px solid rgba(255, 255, 255, 0.18);
    box-shadow: 8px 0px 32px rgba(59, 10, 34, 0.25);
}

section[data-testid="stSidebar"] * {
    color: #f5e9f0 !important; /* soft off-white text */
}

section[data-testid="stSidebar"] h1,
section[data-testid="stSidebar"] h2,
section[data-testid="stSidebar"] h3 {
    color: #f4e6ed !important; /* slightly warmer heading color */
}

section[data-testid="stSidebar"] .stRadio label {
    background: rgba(255, 255, 255, 0.08); /* subtle highlight */
    padding: 10px 13px;
    border-radius: 15px;
    margin-bottom: 8px;
    border: 1px solid rgba(255,255,255,0.12);
    transition: all 0.25s ease-in-out;
}

section[data-testid="stSidebar"] .stRadio label:hover {
    background: rgba(251, 191, 36, 0.23);
    transform: translateX(5px);
    border: 1px solid rgba(251, 191, 36, 0.55);
}

section[data-testid="stSidebar"] div[data-baseweb="input"] {
    background: rgba(255, 255, 255, 0.06); /* very subtle, keeps gradient visible */
    border-radius: 12px;
}

section[data-testid="stSidebar"] input {
    color: #000000 !important; /* soft off-white for inputs */
    font-weight: 700;
}

section[data-testid="stSidebar"] .stNumberInput {
    background: rgba(255, 255, 255, 0.03); /* subtle overlay */
    padding: 5px;
    border-radius: 12px;
}

section[data-testid="stSidebar"] [data-testid="stExpander"] {
    background: rgba(255, 255, 255, 0.05); /* slightly transparent to blend with gradient */
    border-radius: 18px;
    border: 1px solid rgba(255,255,255,0.12);
}
    /* ============================================================
       HERO SECTION
    ============================================================ */

    .hero-card {
        background:
            linear-gradient(135deg, rgba(59,10,34,0.98) 0%, rgba(122,28,75,0.96) 46%, rgba(20,83,79,0.96) 100%);
        padding: 36px 40px;
        border-radius: 30px;
        box-shadow: 0px 20px 50px rgba(59, 10, 34, 0.28);
        border: 1px solid rgba(255,255,255,0.22);
        margin-bottom: 25px;
        position: relative;
        overflow: hidden;
    }

    .hero-card:before {
        content: "";
        position: absolute;
        width: 260px;
        height: 260px;
        right: -80px;
        top: -80px;
        background: rgba(251, 191, 36, 0.18);
        border-radius: 50%;
    }

    .hero-title {
        font-size: 38px;
        font-weight: 950;
        line-height: 1.12;
        color: #fffaf5;
        max-width: 1100px;
        position: relative;
        z-index: 2;
    }

    .hero-subtitle {
        font-size: 16px;
        line-height: 1.65;
        color: #fdebd3;
        max-width: 1180px;
        margin-top: 12px;
        position: relative;
        z-index: 2;
    }

    .badge-row {
        margin-top: 18px;
        position: relative;
        z-index: 2;
    }

    .student-badge {
        display: inline-block;
        background: rgba(255,255,255,0.14);
        color: #fffaf5;
        padding: 9px 15px;
        border-radius: 999px;
        font-weight: 850;
        font-size: 14px;
        border: 1px solid rgba(255,255,255,0.22);
        margin-right: 8px;
        margin-bottom: 8px;
    }

    .gold-badge {
        display: inline-block;
        background: linear-gradient(135deg, #f59e0b, #f97316);
        color: #2b1204;
        padding: 9px 15px;
        border-radius: 999px;
        font-weight: 900;
        font-size: 14px;
        margin-right: 8px;
        margin-bottom: 8px;
        box-shadow: 0px 8px 20px rgba(245, 158, 11, 0.25);
    }

    .teal-badge {
        display: inline-block;
        background: linear-gradient(135deg, #2dd4bf, #14b8a6);
        color: #052f2d;
        padding: 9px 15px;
        border-radius: 999px;
        font-weight: 900;
        font-size: 14px;
        margin-bottom: 8px;
        box-shadow: 0px 8px 20px rgba(20, 184, 166, 0.22);
    }

    /* ============================================================
       HEADINGS
    ============================================================ */

    h1, h2, h3 {
        color: #311827;
        font-weight: 900;
    }

    .page-heading {
        font-size: 28px;
        font-weight: 950;
        color: #311827;
        margin-top: 6px;
        margin-bottom: 8px;
    }

    .page-caption {
        color: #6b3d4f;
        font-size: 15px;
        margin-bottom: 18px;
        line-height: 1.55;
    }

    /* ============================================================
       KPI CARDS
    ============================================================ */

    .kpi-card {
        padding: 23px;
        border-radius: 26px;
        min-height: 142px;
        border: 1px solid rgba(255,255,255,0.72);
        box-shadow: 0px 14px 34px rgba(49, 24, 39, 0.13);
        transition: all 0.26s ease-in-out;
        position: relative;
        overflow: hidden;
    }

    .kpi-card:hover {
        transform: translateY(-6px);
        box-shadow: 0px 22px 48px rgba(49, 24, 39, 0.22);
    }

    .kpi-card:after {
        content: "";
        position: absolute;
        right: -35px;
        top: -35px;
        width: 95px;
        height: 95px;
        border-radius: 50%;
        background: rgba(255,255,255,0.26);
    }

    .kpi-income {
        background: linear-gradient(135deg, #ccfbf1 0%, #14b8a6 100%);
    }

    .kpi-expense {
        background: linear-gradient(135deg, #ffe4e6 0%, #f43f5e 100%);
    }

    .kpi-balance {
        background: linear-gradient(135deg, #dcfce7 0%, #22c55e 100%);
    }

    .kpi-saving {
        background: linear-gradient(135deg, #fef3c7 0%, #f59e0b 100%);
    }

    .kpi-label {
        font-size: 14px;
        color: #3b1d28;
        font-weight: 900;
        letter-spacing: 0.3px;
        position: relative;
        z-index: 2;
    }

    .kpi-value {
        font-size: 31px;
        color: #180a10;
        font-weight: 950;
        margin-top: 10px;
        position: relative;
        z-index: 2;
    }

    .kpi-note {
        font-size: 12px;
        color: rgba(24, 10, 16, 0.75);
        font-weight: 700;
        margin-top: 8px;
        position: relative;
        z-index: 2;
    }

    /* ============================================================
       CONTENT CARDS
    ============================================================ */

    .glass-card {
        background: rgba(255, 255, 255, 0.82);
        backdrop-filter: blur(18px);
        border-radius: 26px;
        padding: 25px;
        border: 1px solid rgba(255,255,255,0.72);
        box-shadow: 0px 14px 35px rgba(49, 24, 39, 0.10);
        margin-bottom: 22px;
        transition: all 0.22s ease-in-out;
    }

    .glass-card:hover {
        transform: translateY(-3px);
        box-shadow: 0px 18px 44px rgba(49, 24, 39, 0.14);
    }

    .mini-card {
        background: rgba(255,255,255,0.78);
        padding: 18px;
        border-radius: 22px;
        border: 1px solid rgba(255,255,255,0.70);
        box-shadow: 0px 12px 28px rgba(49,24,39,0.08);
        margin-bottom: 15px;
    }

    /* ============================================================
       RISK / ALERT BOXES
    ============================================================ */

    .safe-box {
        background: linear-gradient(135deg, #ecfdf5 0%, #bbf7d0 100%);
        border-left: 9px solid #10b981;
        padding: 20px 23px;
        border-radius: 20px;
        color: #064e3b;
        margin-bottom: 14px;
        box-shadow: 0px 12px 28px rgba(16,185,129,0.14);
    }

    .medium-box {
        background: linear-gradient(135deg, #fff7ed 0%, #fed7aa 100%);
        border-left: 9px solid #f97316;
        padding: 20px 23px;
        border-radius: 20px;
        color: #7c2d12;
        margin-bottom: 14px;
        box-shadow: 0px 12px 28px rgba(249,115,22,0.14);
    }

    .risk-box {
        background: linear-gradient(135deg, #fff1f2 0%, #fecdd3 100%);
        border-left: 9px solid #e11d48;
        padding: 20px 23px;
        border-radius: 20px;
        color: #881337;
        margin-bottom: 14px;
        box-shadow: 0px 12px 28px rgba(225,29,72,0.14);
    }

    .info-box {
        background: linear-gradient(135deg, #fdf2f8 0%, #fbcfe8 100%);
        border-left: 9px solid #db2777;
        padding: 20px 23px;
        border-radius: 20px;
        color: #831843;
        margin-bottom: 14px;
        box-shadow: 0px 12px 28px rgba(219,39,119,0.12);
    }

    .teal-box {
        background: linear-gradient(135deg, #f0fdfa 0%, #99f6e4 100%);
        border-left: 9px solid #0f766e;
        padding: 20px 23px;
        border-radius: 20px;
        color: #134e4a;
        margin-bottom: 14px;
        box-shadow: 0px 12px 28px rgba(15,118,110,0.12);
    }

    /* ============================================================
       TABLES, METRICS, WIDGETS
    ============================================================ */

    div[data-testid="stDataFrame"] {
        background: rgba(255,255,255,0.9);
        border-radius: 20px;
        padding: 10px;
        box-shadow: 0px 12px 30px rgba(49,24,39,0.08);
        border: 1px solid rgba(255,255,255,0.75);
    }

    div[data-testid="metric-container"] {
        background: rgba(255,255,255,0.82);
        border: 1px solid rgba(255,255,255,0.72);
        padding: 16px;
        border-radius: 22px;
        box-shadow: 0px 10px 25px rgba(49,24,39,0.08);
    }

    .stSlider > div {
        color: #311827 !important;
    }

    .stButton > button {
        background: linear-gradient(135deg, #be123c, #0f766e);
        color: white;
        border: none;
        border-radius: 16px;
        font-weight: 900;
        padding: 0.7rem 1.25rem;
        box-shadow: 0px 10px 25px rgba(190, 18, 60, 0.22);
        transition: all 0.22s ease-in-out;
    }

    .stButton > button:hover {
        background: linear-gradient(135deg, #9f1239, #115e59);
        transform: translateY(-3px);
        box-shadow: 0px 16px 34px rgba(190, 18, 60, 0.30);
    }

    /* ============================================================
       FOOTER
    ============================================================ */

    .footer {
        text-align: center;
        color: #4a102a;
        font-size: 13px;
        font-weight: 700;
        margin-top: 35px;
        padding: 18px;
        background: rgba(255,255,255,0.72);
        border-radius: 22px;
        border: 1px solid rgba(255,255,255,0.75);
        box-shadow: 0px 12px 28px rgba(49,24,39,0.08);
    }

    </style>
    """,
    unsafe_allow_html=True
)


# ============================================================
# FILE PATHS
# ============================================================

MODEL_PATH = "models/budget_risk_model.pkl"
SCALER_PATH = "models/scaler.pkl"
ENCODER_PATH = "models/label_encoder.pkl"
FEATURES_PATH = "models/feature_columns.pkl"
DATASET_PATH = "data/synthetic_budget_dataset.csv"


# ============================================================
# LOAD MODEL AND DATASET
# ============================================================

@st.cache_resource
def load_ml_resources():
    required_files = [MODEL_PATH, SCALER_PATH, ENCODER_PATH, FEATURES_PATH]
    missing_files = [file for file in required_files if not os.path.exists(file)]

    if missing_files:
        return None, None, None, None, missing_files

    model = joblib.load(MODEL_PATH)
    scaler = joblib.load(SCALER_PATH)
    label_encoder = joblib.load(ENCODER_PATH)
    feature_info = joblib.load(FEATURES_PATH)

    if isinstance(feature_info, dict):
        feature_columns = feature_info.get("feature_columns")
    else:
        feature_columns = feature_info

    return model, scaler, label_encoder, feature_columns, []


@st.cache_data
def load_dataset():
    if os.path.exists(DATASET_PATH):
        return pd.read_csv(DATASET_PATH)
    return None


model, scaler, label_encoder, feature_columns, missing_files = load_ml_resources()
dataset = load_dataset()


# ============================================================
# HELPER FUNCTIONS
# ============================================================

def money(value):
    return f"£{value:,.2f}"


def money0(value):
    return f"£{value:,.0f}"


def pct(value):
    return f"{value:.2f}%"


def calculate_budget_values(
    monthly_income,
    rent,
    food,
    transport,
    utilities,
    entertainment,
    healthcare,
    education,
    unexpected_expense,
    savings_target
):
    total_expense = (
        rent + food + transport + utilities +
        entertainment + healthcare + education +
        unexpected_expense
    )

    remaining_balance = monthly_income - total_expense
    expense_income_ratio = total_expense / monthly_income if monthly_income > 0 else 0
    savings_gap = remaining_balance - savings_target

    return {
        "total_expense": total_expense,
        "remaining_balance": remaining_balance,
        "expense_income_ratio": expense_income_ratio,
        "savings_gap": savings_gap
    }


def rule_based_risk(remaining_balance, expense_income_ratio, savings_gap):
    if remaining_balance < 0 or expense_income_ratio > 1.0:
        return "High Risk"
    if savings_gap < 0 or expense_income_ratio > 0.75:
        return "Medium Risk"
    return "Low Risk"


def risk_score(expense_income_ratio, savings_gap, remaining_balance):
    score = 100
    score -= min(expense_income_ratio * 65, 70)

    if savings_gap < 0:
        score -= min(abs(savings_gap) / 20, 25)

    if remaining_balance < 0:
        score -= 20

    return max(0, min(100, round(score, 1)))


def risk_badge(risk_label):
    if risk_label == "High Risk":
        return "risk-box", "🔴"
    if risk_label == "Medium Risk":
        return "medium-box", "🟠"
    return "safe-box", "🟢"


def generate_recommendations(
    monthly_income,
    rent,
    food,
    transport,
    utilities,
    entertainment,
    healthcare,
    education,
    unexpected_expense,
    savings_target,
    total_expense,
    remaining_balance,
    expense_income_ratio,
    savings_gap
):
    recommendations = []

    if monthly_income <= 0:
        return [("High", "Monthly income must be greater than zero for reliable budget analysis.")]

    if total_expense > monthly_income:
        recommendations.append(
            ("High", "Total expenses are higher than monthly income. Immediate cost review is required.")
        )

    if remaining_balance < 0:
        recommendations.append(
            ("High", "The current budget creates a negative balance. Essential and flexible expenses should be reviewed.")
        )

    if savings_gap < 0:
        recommendations.append(
            ("Medium", f"The savings target is not currently achievable. The shortfall is {money(abs(savings_gap))}.")
        )

    if rent / monthly_income > 0.40:
        recommendations.append(
            ("Medium", "Rent or housing cost is above 40% of income, which may reduce affordability.")
        )

    if food / monthly_income > 0.20:
        recommendations.append(
            ("Medium", "Food spending is above 20% of income. Reviewing grocery or dining costs may improve savings.")
        )

    if entertainment / monthly_income > 0.15:
        recommendations.append(
            ("Medium", "Entertainment spending is relatively high. Reducing non-essential spending may improve budget stability.")
        )

    if unexpected_expense / monthly_income > 0.20:
        recommendations.append(
            ("Medium", "Unexpected expenses are high compared with income. An emergency reserve should be considered.")
        )

    if expense_income_ratio <= 0.60 and savings_gap >= 0:
        recommendations.append(
            ("Low", "The budget is stable. Expenses are controlled and the savings target appears achievable.")
        )

    if 0.60 < expense_income_ratio <= 0.75 and savings_gap >= 0:
        recommendations.append(
            ("Low", "The budget is manageable, but spending should be monitored to protect savings.")
        )

    if not recommendations:
        recommendations.append(
            ("Low", "No major financial risk was detected. Continue monitoring expenses regularly.")
        )

    return recommendations


def predict_ml_risk(input_data):
    if model is None or scaler is None or label_encoder is None or feature_columns is None:
        return None

    input_df = pd.DataFrame([input_data])
    input_df = input_df[feature_columns]

    scaled_input = scaler.transform(input_df)
    prediction = model.predict(scaled_input)
    predicted_label = label_encoder.inverse_transform(prediction)[0]

    probabilities = None
    if hasattr(model, "predict_proba"):
        probabilities = model.predict_proba(scaled_input)[0]

    return predicted_label, probabilities


def create_expense_dataframe(
    rent,
    food,
    transport,
    utilities,
    entertainment,
    healthcare,
    education,
    unexpected_expense
):
    return pd.DataFrame({
        "Category": [
            "Rent",
            "Food",
            "Transport",
            "Utilities",
            "Entertainment",
            "Healthcare",
            "Education",
            "Unexpected"
        ],
        "Amount": [
            rent,
            food,
            transport,
            utilities,
            entertainment,
            healthcare,
            education,
            unexpected_expense
        ]
    })


def display_recommendation(level, message):
    if level == "High":
        box = "risk-box"
        label = "High Priority"
    elif level == "Medium":
        box = "medium-box"
        label = "Medium Priority"
    else:
        box = "safe-box"
        label = "Stable"

    st.markdown(
        f"""
        <div class="{box}">
            <strong>{label}:</strong> {message}
        </div>
        """,
        unsafe_allow_html=True
    )


def apply_plot_theme(fig, height=430):
    fig.update_layout(
        height=height,
        paper_bgcolor="rgba(255,255,255,0)",
        plot_bgcolor="rgba(255,255,255,0)",
        font=dict(color="#311827", family="Arial"),
        title_font=dict(size=18, color="#311827"),
        margin=dict(l=20, r=20, t=55, b=30),
        legend=dict(
            bgcolor="rgba(255,255,255,0.55)",
            bordercolor="rgba(255,255,255,0.65)",
            borderwidth=1
        )
    )
    return fig


CUSTOM_COLORS = [
    "#be123c", "#f97316", "#f59e0b", "#14b8a6",
    "#0f766e", "#db2777", "#84cc16", "#a16207"
]


# ============================================================
# SIDEBAR
# ============================================================

st.sidebar.markdown("## 💷 Personal Budget DSS")
st.sidebar.markdown("### Kiran Dasangri Chalapathi")
st.sidebar.markdown("**MSc Final Year Project**")
st.sidebar.markdown("---")

page = st.sidebar.radio(
    "Navigation",
    [
        "Home Dashboard",
        "Budget Analysis",
        "ML Prediction",
        "Scenario Simulator",
        "Results & Reports",
        "Dataset & Model",
        "About Project"
    ]
)

st.sidebar.markdown("---")
st.sidebar.markdown("### Monthly Budget Inputs")

with st.sidebar.expander("Enter Budget Data", expanded=True):
    monthly_income = st.number_input("Monthly Income (£)", min_value=0.0, value=2500.0, step=50.0)
    rent = st.number_input("Rent / Housing (£)", min_value=0.0, value=850.0, step=25.0)
    food = st.number_input("Food (£)", min_value=0.0, value=350.0, step=25.0)
    transport = st.number_input("Transport (£)", min_value=0.0, value=180.0, step=10.0)
    utilities = st.number_input("Utilities (£)", min_value=0.0, value=220.0, step=10.0)
    entertainment = st.number_input("Entertainment (£)", min_value=0.0, value=200.0, step=10.0)
    healthcare = st.number_input("Healthcare (£)", min_value=0.0, value=120.0, step=10.0)
    education = st.number_input("Education (£)", min_value=0.0, value=100.0, step=10.0)
    unexpected_expense = st.number_input("Unexpected Expense (£)", min_value=0.0, value=150.0, step=25.0)
    savings_target = st.number_input("Savings Target (£)", min_value=0.0, value=500.0, step=25.0)

st.sidebar.markdown("---")
st.sidebar.markdown(
    """
    **Project Modules**
    - Budget dashboard  
    - DSS recommendations  
    - ML risk prediction  
    - Scenario simulation  
    - Results and reports  
    - Dataset inspection  
    """
)

st.sidebar.markdown("---")
st.sidebar.info(
    "Academic prototype only. This system supports personal budget planning but does not provide professional financial advice."
)


# ============================================================
# MAIN HEADER
# ============================================================

st.markdown(
    """
    <div class="hero-card">
        <div class="hero-title">
            Web-Based Decision Support System for Personal Budget Planning
        </div>
        <div class="hero-subtitle">
            A professional MSc final-year project prototype combining rule-based decision support,
            machine-learning risk prediction, visual analytics, and what-if scenario comparison
            for personal budgeting decisions.
        </div>
        <div class="badge-row">
            <span class="student-badge">Student: Kiran Dasangri Chalapathi</span>
            <span class="gold-badge">Decision Support System</span>
            <span class="teal-badge">Machine-Learning Assisted Prototype</span>
        </div>
    </div>
    """,
    unsafe_allow_html=True
)


# ============================================================
# CALCULATIONS
# ============================================================

calculated = calculate_budget_values(
    monthly_income,
    rent,
    food,
    transport,
    utilities,
    entertainment,
    healthcare,
    education,
    unexpected_expense,
    savings_target
)

total_expense = calculated["total_expense"]
remaining_balance = calculated["remaining_balance"]
expense_income_ratio = calculated["expense_income_ratio"]
savings_gap = calculated["savings_gap"]
rule_risk = rule_based_risk(remaining_balance, expense_income_ratio, savings_gap)
budget_health_score = risk_score(expense_income_ratio, savings_gap, remaining_balance)

input_data = {
    "monthly_income": monthly_income,
    "rent": rent,
    "food": food,
    "transport": transport,
    "utilities": utilities,
    "entertainment": entertainment,
    "healthcare": healthcare,
    "education": education,
    "unexpected_expense": unexpected_expense,
    "savings_target": savings_target,
    "total_expense": total_expense,
    "remaining_balance": remaining_balance,
    "expense_income_ratio": expense_income_ratio,
    "savings_gap": savings_gap
}

ml_result = predict_ml_risk(input_data)
if ml_result is not None:
    ml_risk, ml_probabilities = ml_result
else:
    ml_risk, ml_probabilities = None, None

recommendations = generate_recommendations(
    monthly_income,
    rent,
    food,
    transport,
    utilities,
    entertainment,
    healthcare,
    education,
    unexpected_expense,
    savings_target,
    total_expense,
    remaining_balance,
    expense_income_ratio,
    savings_gap
)

expense_df = create_expense_dataframe(
    rent,
    food,
    transport,
    utilities,
    entertainment,
    healthcare,
    education,
    unexpected_expense
)


# ============================================================
# PAGE: HOME DASHBOARD
# ============================================================

if page == "Home Dashboard":
    st.markdown('<div class="page-heading">Executive Budget Dashboard</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="page-caption">A high-level decision-support summary of the current monthly budget condition.</div>',
        unsafe_allow_html=True
    )

    col1, col2, col3, col4 = st.columns(4)

    with col1:
        st.markdown(
            f"""
            <div class="kpi-card kpi-income">
                <div class="kpi-label">Monthly Income</div>
                <div class="kpi-value">{money0(monthly_income)}</div>
                <div class="kpi-note">User-entered income</div>
            </div>
            """,
            unsafe_allow_html=True
        )

    with col2:
        st.markdown(
            f"""
            <div class="kpi-card kpi-expense">
                <div class="kpi-label">Total Expenses</div>
                <div class="kpi-value">{money0(total_expense)}</div>
                <div class="kpi-note">All expense categories</div>
            </div>
            """,
            unsafe_allow_html=True
        )

    with col3:
        st.markdown(
            f"""
            <div class="kpi-card kpi-balance">
                <div class="kpi-label">Remaining Balance</div>
                <div class="kpi-value">{money0(remaining_balance)}</div>
                <div class="kpi-note">Income minus expenses</div>
            </div>
            """,
            unsafe_allow_html=True
        )

    with col4:
        st.markdown(
            f"""
            <div class="kpi-card kpi-saving">
                <div class="kpi-label">Savings Gap</div>
                <div class="kpi-value">{money0(savings_gap)}</div>
                <div class="kpi-note">Balance minus target</div>
            </div>
            """,
            unsafe_allow_html=True
        )

    st.markdown("<br>", unsafe_allow_html=True)

    risk_box, risk_icon = risk_badge(rule_risk)
    st.markdown(
        f"""
        <div class="{risk_box}">
            <h3>{risk_icon} Rule-Based DSS Status: {rule_risk}</h3>
            <p>
            The DSS checks the current budget using expense-to-income ratio, remaining balance,
            and savings target achievement.
            </p>
        </div>
        """,
        unsafe_allow_html=True
    )

    if ml_risk is not None:
        ml_box, ml_icon = risk_badge(ml_risk)
        st.markdown(
            f"""
            <div class="{ml_box}">
                <h3>{ml_icon} Machine-Learning Predicted Risk: {ml_risk}</h3>
                <p>
                The trained Random Forest model predicts the budget risk level using financial indicators
                generated from the current input values.
                </p>
            </div>
            """,
            unsafe_allow_html=True
        )
    else:
        st.markdown(
            """
            <div class="risk-box">
                <strong>Model files missing:</strong> Please place the trained model files inside the models folder.
            </div>
            """,
            unsafe_allow_html=True
        )

    chart_col1, chart_col2 = st.columns(2)

    with chart_col1:
        st.markdown('<div class="glass-card">', unsafe_allow_html=True)
        fig_pie = px.pie(
            expense_df,
            names="Category",
            values="Amount",
            hole=0.48,
            title="Expense Category Distribution",
            color_discrete_sequence=CUSTOM_COLORS
        )
        fig_pie = apply_plot_theme(fig_pie, height=440)
        st.plotly_chart(fig_pie, use_container_width=True)
        st.markdown('</div>', unsafe_allow_html=True)

    with chart_col2:
        st.markdown('<div class="glass-card">', unsafe_allow_html=True)
        summary_df = pd.DataFrame({
            "Indicator": ["Income", "Expenses", "Remaining Balance", "Savings Target"],
            "Amount": [monthly_income, total_expense, remaining_balance, savings_target]
        })

        fig_bar = px.bar(
            summary_df,
            x="Indicator",
            y="Amount",
            text="Amount",
            title="Income, Expense and Savings Overview",
            color="Indicator",
            color_discrete_sequence=CUSTOM_COLORS
        )
        fig_bar.update_traces(texttemplate="£%{text:,.0f}", textposition="outside")
        fig_bar = apply_plot_theme(fig_bar, height=440)
        st.plotly_chart(fig_bar, use_container_width=True)
        st.markdown('</div>', unsafe_allow_html=True)

    st.markdown("## Key Decision-Support Recommendations")
    for level, message in recommendations[:5]:
        display_recommendation(level, message)


# ============================================================
# PAGE: BUDGET ANALYSIS
# ============================================================

elif page == "Budget Analysis":
    st.markdown('<div class="page-heading">Detailed Budget Analysis</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="page-caption">This page explains spending behaviour, category pressure, rule outcomes, and savings feasibility.</div>',
        unsafe_allow_html=True
    )

    col_a, col_b = st.columns([1.2, 1])

    with col_a:
        expense_table = expense_df.copy()
        expense_table["Percentage of Income"] = expense_table["Amount"].apply(
            lambda x: (x / monthly_income * 100) if monthly_income > 0 else 0
        )
        expense_table["Amount Display"] = expense_table["Amount"].apply(money)
        expense_table["Percentage Display"] = expense_table["Percentage of Income"].apply(lambda x: f"{x:.2f}%")

        st.markdown("### Category-Wise Expense Table")
        st.dataframe(
            expense_table[["Category", "Amount Display", "Percentage Display"]],
            use_container_width=True,
            hide_index=True
        )

    with col_b:
        st.markdown("### Budget Health Indicators")
        st.metric("Expense-to-Income Ratio", pct(expense_income_ratio * 100))
        st.metric("Budget Health Score", f"{budget_health_score}/100")
        st.metric("Remaining Balance", money(remaining_balance))
        st.metric("Savings Gap", money(savings_gap))

    st.markdown("### Category Pressure Analysis")

    percentage_df = expense_df.copy()
    percentage_df["Percentage"] = percentage_df["Amount"].apply(
        lambda x: (x / monthly_income * 100) if monthly_income > 0 else 0
    )

    fig_pct = px.bar(
        percentage_df,
        x="Category",
        y="Percentage",
        text="Percentage",
        title="Expense Category as Percentage of Monthly Income",
        color="Category",
        color_discrete_sequence=CUSTOM_COLORS
    )
    fig_pct.update_traces(texttemplate="%{text:.1f}%", textposition="outside")
    fig_pct = apply_plot_theme(fig_pct, height=460)
    st.plotly_chart(fig_pct, use_container_width=True)

    st.markdown("### DSS Rule Evaluation Table")

    rules_df = pd.DataFrame({
        "Decision Rule": [
            "Expenses should not exceed income",
            "Expense-income ratio should remain below 75%",
            "Remaining balance should meet savings target",
            "Rent should not exceed 40% of income",
            "Food should not exceed 20% of income",
            "Entertainment should not exceed 15% of income"
        ],
        "Current Value": [
            f"{money(total_expense)} vs {money(monthly_income)}",
            pct(expense_income_ratio * 100),
            f"Gap: {money(savings_gap)}",
            pct((rent / monthly_income * 100) if monthly_income > 0 else 0),
            pct((food / monthly_income * 100) if monthly_income > 0 else 0),
            pct((entertainment / monthly_income * 100) if monthly_income > 0 else 0)
        ],
        "Status": [
            "Violated" if total_expense > monthly_income else "Satisfied",
            "Violated" if expense_income_ratio > 0.75 else "Satisfied",
            "Violated" if savings_gap < 0 else "Satisfied",
            "Violated" if monthly_income > 0 and rent / monthly_income > 0.40 else "Satisfied",
            "Violated" if monthly_income > 0 and food / monthly_income > 0.20 else "Satisfied",
            "Violated" if monthly_income > 0 and entertainment / monthly_income > 0.15 else "Satisfied"
        ]
    })

    st.dataframe(rules_df, use_container_width=True, hide_index=True)

    st.markdown("### Full Recommendation Output")
    for level, message in recommendations:
        display_recommendation(level, message)


# ============================================================
# PAGE: ML PREDICTION
# ============================================================

elif page == "ML Prediction":
    st.markdown('<div class="page-heading">Machine-Learning Risk Prediction</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="page-caption">This page shows the machine-learning risk classification generated from the current budget profile.</div>',
        unsafe_allow_html=True
    )

    if ml_risk is None:
        st.markdown(
            """
            <div class="risk-box">
                <h3>Model files not available</h3>
                <p>Please make sure the model, scaler, label encoder, and feature column files are inside the models folder.</p>
            </div>
            """,
            unsafe_allow_html=True
        )
    else:
        ml_box, ml_icon = risk_badge(ml_risk)
        st.markdown(
            f"""
            <div class="{ml_box}">
                <h3>{ml_icon} Predicted Budget Risk: {ml_risk}</h3>
                <p>
                The machine-learning model uses the current financial indicators to classify budget risk.
                This supports the DSS by adding a predictive layer to the rule-based analysis.
                </p>
            </div>
            """,
            unsafe_allow_html=True
        )

        if ml_probabilities is not None:
            prob_df = pd.DataFrame({
                "Risk Class": label_encoder.classes_,
                "Probability": ml_probabilities
            })

            fig_prob = px.bar(
                prob_df,
                x="Risk Class",
                y="Probability",
                text="Probability",
                title="Prediction Probability by Risk Class",
                color="Risk Class",
                color_discrete_sequence=CUSTOM_COLORS
            )
            fig_prob.update_traces(texttemplate="%{text:.2f}", textposition="outside")
            fig_prob = apply_plot_theme(fig_prob, height=450)
            st.plotly_chart(fig_prob, use_container_width=True)

        st.markdown("### Current Model Input Features")

        input_feature_df = pd.DataFrame({
            "Feature": list(input_data.keys()),
            "Value": list(input_data.values())
        })

        st.dataframe(input_feature_df, use_container_width=True, hide_index=True)


# ============================================================
# PAGE: SCENARIO SIMULATOR
# ============================================================

elif page == "Scenario Simulator":
    st.markdown('<div class="page-heading">What-if Scenario Simulator</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="page-caption">Simulate changes such as income drop, rent increase, unexpected expense increase, or savings target adjustment.</div>',
        unsafe_allow_html=True
    )

    with st.container():
        col1, col2, col3, col4 = st.columns(4)

        with col1:
            income_change_percent = st.slider("Income Change (%)", min_value=-50, max_value=50, value=-10, step=5)

        with col2:
            rent_change = st.number_input("Rent Change (£)", value=150.0, step=25.0)

        with col3:
            unexpected_change = st.number_input("Unexpected Expense Change (£)", value=200.0, step=25.0)

        with col4:
            savings_target_change = st.number_input("Savings Target Change (£)", value=0.0, step=25.0)

    scenario_income = monthly_income + (monthly_income * income_change_percent / 100)
    scenario_rent = max(0, rent + rent_change)
    scenario_unexpected = max(0, unexpected_expense + unexpected_change)
    scenario_savings_target = max(0, savings_target + savings_target_change)

    scenario_calculated = calculate_budget_values(
        scenario_income,
        scenario_rent,
        food,
        transport,
        utilities,
        entertainment,
        healthcare,
        education,
        scenario_unexpected,
        scenario_savings_target
    )

    scenario_total_expense = scenario_calculated["total_expense"]
    scenario_remaining_balance = scenario_calculated["remaining_balance"]
    scenario_expense_income_ratio = scenario_calculated["expense_income_ratio"]
    scenario_savings_gap = scenario_calculated["savings_gap"]
    scenario_rule_risk = rule_based_risk(
        scenario_remaining_balance,
        scenario_expense_income_ratio,
        scenario_savings_gap
    )

    scenario_input_data = {
        "monthly_income": scenario_income,
        "rent": scenario_rent,
        "food": food,
        "transport": transport,
        "utilities": utilities,
        "entertainment": entertainment,
        "healthcare": healthcare,
        "education": education,
        "unexpected_expense": scenario_unexpected,
        "savings_target": scenario_savings_target,
        "total_expense": scenario_total_expense,
        "remaining_balance": scenario_remaining_balance,
        "expense_income_ratio": scenario_expense_income_ratio,
        "savings_gap": scenario_savings_gap
    }

    scenario_ml_result = predict_ml_risk(scenario_input_data)
    if scenario_ml_result is not None:
        scenario_ml_risk, _ = scenario_ml_result
    else:
        scenario_ml_risk = None

    st.markdown("### Current Budget vs Scenario Budget")

    comparison_df = pd.DataFrame({
        "Indicator": [
            "Monthly Income",
            "Total Expenses",
            "Remaining Balance",
            "Savings Target",
            "Savings Gap",
            "Expense-Income Ratio"
        ],
        "Current Budget": [
            monthly_income,
            total_expense,
            remaining_balance,
            savings_target,
            savings_gap,
            expense_income_ratio * 100
        ],
        "Scenario Budget": [
            scenario_income,
            scenario_total_expense,
            scenario_remaining_balance,
            scenario_savings_target,
            scenario_savings_gap,
            scenario_expense_income_ratio * 100
        ]
    })

    display_df = comparison_df.copy()
    for column in ["Current Budget", "Scenario Budget"]:
        display_df[column] = display_df.apply(
            lambda row: f"{row[column]:.2f}%" if row["Indicator"] == "Expense-Income Ratio" else money(row[column]),
            axis=1
        )

    st.dataframe(display_df, use_container_width=True, hide_index=True)

    fig_scenario = go.Figure()
    fig_scenario.add_trace(
        go.Bar(
            name="Current Budget",
            x=comparison_df["Indicator"],
            y=comparison_df["Current Budget"],
            marker_color="#be123c"
        )
    )
    fig_scenario.add_trace(
        go.Bar(
            name="Scenario Budget",
            x=comparison_df["Indicator"],
            y=comparison_df["Scenario Budget"],
            marker_color="#14b8a6"
        )
    )
    fig_scenario.update_layout(
        title="Current Budget vs Scenario Budget",
        barmode="group"
    )
    fig_scenario = apply_plot_theme(fig_scenario, height=470)
    st.plotly_chart(fig_scenario, use_container_width=True)

    col_r1, col_r2 = st.columns(2)

    with col_r1:
        box, icon = risk_badge(rule_risk)
        st.markdown(
            f"""
            <div class="{box}">
                <h3>{icon} Current Rule-Based Risk: {rule_risk}</h3>
            </div>
            """,
            unsafe_allow_html=True
        )

    with col_r2:
        box, icon = risk_badge(scenario_rule_risk)
        st.markdown(
            f"""
            <div class="{box}">
                <h3>{icon} Scenario Rule-Based Risk: {scenario_rule_risk}</h3>
            </div>
            """,
            unsafe_allow_html=True
        )

    if scenario_remaining_balance < remaining_balance:
        st.markdown(
            f"""
            <div class="medium-box">
                The scenario reduces the remaining balance by {money(abs(scenario_remaining_balance - remaining_balance))}.
                This indicates reduced affordability under the tested condition.
            </div>
            """,
            unsafe_allow_html=True
        )
    else:
        st.markdown(
            """
            <div class="safe-box">
                The scenario does not reduce the remaining balance. The tested condition appears manageable.
            </div>
            """,
            unsafe_allow_html=True
        )

    if scenario_savings_gap < 0:
        st.markdown(
            f"""
            <div class="risk-box">
                Under this scenario, the savings target is not achievable.
                The shortfall is {money(abs(scenario_savings_gap))}.
            </div>
            """,
            unsafe_allow_html=True
        )
    else:
        st.markdown(
            """
            <div class="safe-box">
                Under this scenario, the savings target remains achievable.
            </div>
            """,
            unsafe_allow_html=True
        )

    if scenario_ml_risk is not None:
        st.markdown(
            f"""
            <div class="teal-box">
                <strong>Scenario ML Prediction:</strong> {scenario_ml_risk}
            </div>
            """,
            unsafe_allow_html=True
        )


# ============================================================
# PAGE: RESULTS & REPORTS
# ============================================================

elif page == "Results & Reports":
    st.markdown('<div class="page-heading">Results and Decision Report</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="page-caption">This page provides a final decision-support summary that can be used as project evidence or screenshot material.</div>',
        unsafe_allow_html=True
    )

    report_df = pd.DataFrame({
        "Budget Indicator": [
            "Monthly Income",
            "Total Expenses",
            "Remaining Balance",
            "Savings Target",
            "Savings Gap",
            "Expense-to-Income Ratio",
            "Rule-Based Risk",
            "ML Predicted Risk",
            "Budget Health Score"
        ],
        "Result": [
            money(monthly_income),
            money(total_expense),
            money(remaining_balance),
            money(savings_target),
            money(savings_gap),
            pct(expense_income_ratio * 100),
            rule_risk,
            ml_risk if ml_risk is not None else "Model not loaded",
            f"{budget_health_score}/100"
        ]
    })

    st.dataframe(report_df, use_container_width=True, hide_index=True)

    st.markdown("### Final DSS Interpretation")

    if rule_risk == "High Risk":
        st.markdown(
            """
            <div class="risk-box">
                The current budget is classified as high risk. The user should reduce expenses,
                review essential costs, and avoid increasing financial commitments.
            </div>
            """,
            unsafe_allow_html=True
        )
    elif rule_risk == "Medium Risk":
        st.markdown(
            """
            <div class="medium-box">
                The current budget is classified as medium risk. The user should monitor spending,
                review savings feasibility, and reduce flexible expenses where possible.
            </div>
            """,
            unsafe_allow_html=True
        )
    else:
        st.markdown(
            """
            <div class="safe-box">
                The current budget is classified as low risk. Expenses are manageable and the savings position appears stable.
            </div>
            """,
            unsafe_allow_html=True
        )

    st.markdown("### Recommendation Summary")
    for level, message in recommendations:
        display_recommendation(level, message)


# ============================================================
# PAGE: DATASET & MODEL
# ============================================================

elif page == "Dataset & Model":
    st.markdown('<div class="page-heading">Dataset and Model Information</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="page-caption">This page explains the dataset and model files used by the machine-learning component.</div>',
        unsafe_allow_html=True
    )

    if dataset is not None:
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Dataset Records", dataset.shape[0])
        with col2:
            st.metric("Dataset Columns", dataset.shape[1])
        with col3:
            st.metric("Risk Classes", dataset["budget_risk"].nunique() if "budget_risk" in dataset.columns else "N/A")

        st.markdown("### Dataset Preview")
        st.dataframe(dataset.head(20), use_container_width=True)

        if "budget_risk" in dataset.columns:
            risk_counts = dataset["budget_risk"].value_counts().reset_index()
            risk_counts.columns = ["Risk Class", "Count"]

            fig = px.bar(
                risk_counts,
                x="Risk Class",
                y="Count",
                text="Count",
                color="Risk Class",
                title="Risk Class Distribution in Dataset",
                color_discrete_sequence=CUSTOM_COLORS
            )
            fig.update_traces(textposition="outside")
            fig = apply_plot_theme(fig, height=430)
            st.plotly_chart(fig, use_container_width=True)

        st.markdown("### Dataset Summary Statistics")
        st.dataframe(dataset.describe(), use_container_width=True)

    else:
        st.markdown(
            """
            <div class="risk-box">
                Dataset file not found. Please place synthetic_budget_dataset.csv inside the data folder.
            </div>
            """,
            unsafe_allow_html=True
        )

    st.markdown("### Model File Status")

    if missing_files:
        st.markdown(
            """
            <div class="risk-box">
                Some required model files are missing.
            </div>
            """,
            unsafe_allow_html=True
        )
        for file in missing_files:
            st.write(f"- {file}")
    else:
        st.markdown(
            """
            <div class="safe-box">
                All model files are loaded successfully.
            </div>
            """,
            unsafe_allow_html=True
        )
        st.write("Loaded model files:")
        st.write("- budget_risk_model.pkl")
        st.write("- scaler.pkl")
        st.write("- label_encoder.pkl")
        st.write("- feature_columns.pkl")

        st.markdown("### Feature Columns Used by the Model")
        st.write(feature_columns)


# ============================================================
# PAGE: ABOUT PROJECT
# ============================================================

elif page == "About Project":
    st.markdown('<div class="page-heading">About the Project</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="page-caption">Academic overview of the final-year project, system aim, modules, and evaluation evidence.</div>',
        unsafe_allow_html=True
    )

    st.markdown(
        """
        <div class="glass-card">
            <h3>Project Title</h3>
            <p><strong>Design and Implementation of Web-Based Decision Support System for Personal Budget Planning</strong></p>
            <p><strong>Student Name:</strong> Kiran Dasangri Chalapathi</p>
            <p><strong>Project Type:</strong> MSc Final Year Project Prototype</p>
        </div>
        """,
        unsafe_allow_html=True
    )

    st.markdown(
        """
        <div class="info-box">
            <h3>Project Aim</h3>
            <p>
            The aim of this project is to develop a web-based decision support system that helps users analyse
            personal budgeting conditions through budget calculations, rule-based recommendations,
            machine-learning risk prediction, and scenario-based comparison.
            </p>
        </div>
        """,
        unsafe_allow_html=True
    )

    modules_df = pd.DataFrame({
        "Module": [
            "Budget Input Module",
            "Dashboard Module",
            "Budget Analysis Module",
            "Machine-Learning Prediction Module",
            "Rule-Based DSS Module",
            "Scenario Simulator",
            "Results and Reports Module",
            "Dataset and Model Module"
        ],
        "Purpose": [
            "Collects monthly income, expense categories, unexpected costs, and savings target.",
            "Presents a high-level summary of income, expenses, balance, savings gap, and risk.",
            "Explains spending categories, expense pressure, and decision-rule outcomes.",
            "Predicts budget risk using a trained Random Forest model.",
            "Generates explainable recommendations and warnings.",
            "Tests alternative financial situations such as income drop or rent increase.",
            "Provides final budget interpretation and recommendation summary.",
            "Displays dataset preview, model status, and feature details."
        ]
    })

    st.markdown("### Main System Modules")
    st.dataframe(modules_df, use_container_width=True, hide_index=True)

    evaluation_df = pd.DataFrame({
        "Evaluation Area": [
            "Functional Testing",
            "Rule-Based Testing",
            "ML Model Evaluation",
            "Scenario Testing",
            "Usability Review",
            "Privacy and Security Review"
        ],
        "Evidence": [
            "Application pages, inputs, calculations, and charts were tested.",
            "Decision rules were tested using stable, medium-risk, and high-risk budgets.",
            "Accuracy, confusion matrix, classification report, and feature importance were produced in Colab.",
            "Income drop, rent increase, unexpected expense, and savings target changes were tested.",
            "Navigation, readability, dashboard clarity, and task completion were reviewed.",
            "The prototype avoids live banking data and uses synthetic model-training data."
        ]
    })

    st.markdown("### Evaluation Evidence")
    st.dataframe(evaluation_df, use_container_width=True, hide_index=True)

    st.markdown(
        """
        <div class="teal-box">
            <strong>Academic Disclaimer:</strong>
            This system is designed as an academic decision-support prototype. It provides informational support
            for budget planning and should not be interpreted as professional financial advice.
        </div>
        """,
        unsafe_allow_html=True
    )


# ============================================================
# FOOTER
# ============================================================

st.markdown(
    """
    <div class="footer">
        Personal Budget Decision Support System | MSc Final Year Project Prototype | Student: Kiran Dasangri Chalapathi
    </div>
    """,
    unsafe_allow_html=True
)